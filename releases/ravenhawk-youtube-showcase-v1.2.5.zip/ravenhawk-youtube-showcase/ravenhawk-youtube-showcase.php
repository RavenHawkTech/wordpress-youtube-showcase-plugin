<?php
/**
 * Plugin Name: RavenHawk YouTube Showcase
 * Description: Displays RavenHawk Tech YouTube videos using shortcode-based long-form and Shorts filters.
 * Version: 1.2.5
 * Author: RavenHawk Tech
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

class RavenHawk_YouTube_Showcase {
    const OPTION_KEY = 'rht_yt_showcase_options';
    const CACHE_KEY  = 'rht_yt_showcase_videos';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page'], 99);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('ravenhawk_youtube', [$this, 'render_shortcode']);
        add_shortcode('ravenhawk_youtube_showcase', [$this, 'render_shortcode']);
        add_shortcode('ravenhawk_youtube_shorts', [$this, 'render_shorts_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_post_rht_yt_clear_cache', [$this, 'clear_cache']);
    }

    public static function defaults() {
        return [
            'api_key' => '',
            'channel_handle' => '@RavenHawkTech',
            'channel_id' => '',
            'uploads_playlist_id' => '',
            'cache_hours' => 12,
            'max_videos' => 25,
            'title' => 'Latest from RavenHawk Tech',
            'exclude_shorts' => 1,
            'exclude_premieres' => 1,
            'short_title_marker' => '[SHORT]',
            'hide_short_marker' => 1,
        ];
    }

    public function options() {
        return wp_parse_args(get_option(self::OPTION_KEY, []), self::defaults());
    }

    public function add_settings_page() {
        $parent_slug = $this->find_ravenhawktech_parent_slug();

        if (!$parent_slug) {
            add_menu_page(
                'RavenHawkTech',
                'RavenHawkTech',
                'manage_options',
                'ravenhawktech',
                [$this, 'settings_page'],
                'dashicons-shield-alt',
                58
            );
            $parent_slug = 'ravenhawktech';
        }

        add_submenu_page(
            $parent_slug,
            'RavenHawk YouTube Showcase',
            'YouTube Showcase',
            'manage_options',
            'ravenhawk-youtube-showcase',
            [$this, 'settings_page']
        );
    }

    private function find_ravenhawktech_parent_slug() {
        global $menu;

        if (!is_array($menu)) {
            return false;
        }

        foreach ($menu as $item) {
            $title = isset($item[0]) ? wp_strip_all_tags((string) $item[0]) : '';
            $slug  = isset($item[2]) ? (string) $item[2] : '';

            if ($slug && preg_match('/raven\s*hawk\s*tech|ravenhawktech/i', $title . ' ' . $slug)) {
                return $slug;
            }
        }

        return false;
    }

    public function register_settings() {
        register_setting('rht_yt_showcase_group', self::OPTION_KEY, [$this, 'sanitize_options']);
    }

    public function sanitize_options($input) {
        $defaults = self::defaults();
        $out = [];
        $out['api_key'] = sanitize_text_field($input['api_key'] ?? '');
        $out['channel_handle'] = sanitize_text_field($input['channel_handle'] ?? $defaults['channel_handle']);
        $out['channel_id'] = sanitize_text_field($input['channel_id'] ?? '');
        $out['uploads_playlist_id'] = sanitize_text_field($input['uploads_playlist_id'] ?? '');
        $out['cache_hours'] = max(1, absint($input['cache_hours'] ?? $defaults['cache_hours']));
        $out['max_videos'] = min(50, max(5, absint($input['max_videos'] ?? $defaults['max_videos'])));
        $out['title'] = sanitize_text_field($input['title'] ?? $defaults['title']);
        $out['exclude_shorts'] = !empty($input['exclude_shorts']) ? 1 : 0;
        $out['exclude_premieres'] = !empty($input['exclude_premieres']) ? 1 : 0;
        $out['short_title_marker'] = sanitize_text_field($input['short_title_marker'] ?? $defaults['short_title_marker']);
        $out['hide_short_marker'] = !empty($input['hide_short_marker']) ? 1 : 0;
        $this->delete_all_caches();
        return $out;
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $opts = $this->options();
        ?>
        <div class="wrap">
            <h1>RavenHawk YouTube Showcase</h1>
            <p>Use shortcode: <code>[ravenhawk_youtube]</code></p>
            <p>Shorts-only shortcode: <code>[ravenhawk_youtube_shorts]</code> or <code>[ravenhawk_youtube type=&quot;shorts&quot;]</code></p>
            <p><strong>Important:</strong> Use your raw Channel ID and, when possible, the Uploads Playlist ID. The Uploads Playlist ID reduces API requests by skipping channel lookup.</p>
            <p><strong>Filtering note:</strong> Title marker filtering works with RSS and does not require API quota. Duration fallback and Premiere filtering require the YouTube Data API key.</p>
            <?php if (!empty($opts['channel_id'])): ?>
                <p>Current RSS feed: <code><?php echo esc_html('https://www.youtube.com/feeds/videos.xml?channel_id=' . $opts['channel_id']); ?></code></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin: 12px 0 20px;">
                    <?php wp_nonce_field('rht_yt_clear_cache'); ?>
                    <input type="hidden" name="action" value="rht_yt_clear_cache" />
                    <?php submit_button('Clear YouTube Video Cache', 'secondary', 'submit', false); ?>
                </form>
            <?php endif; ?>
            <form method="post" action="options.php">
                <?php settings_fields('rht_yt_showcase_group'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="rht-api-key">YouTube Data API Key</label></th>
                        <td><input id="rht-api-key" type="password" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_key]" value="<?php echo esc_attr($opts['api_key']); ?>" class="regular-text" autocomplete="off" /><p class="description">Optional in v1.2.2. The plugin now uses YouTube RSS first, which does not consume YouTube API quota. Keep the key only as a fallback.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-channel-handle">Channel Handle</label></th>
                        <td><input id="rht-channel-handle" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[channel_handle]" value="<?php echo esc_attr($opts['channel_handle']); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-channel-id">Channel ID optional</label></th>
                        <td><input id="rht-channel-id" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[channel_id]" value="<?php echo esc_attr($opts['channel_id']); ?>" class="regular-text" />
                        <p class="description">Recommended: paste the raw Channel ID, for example <code>UCxxxxxxxxxxxxxxxxxxxxxx</code>. v1.2.2 uses RSS first, then direct uploads playlist API fallback to reduce quota usage.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-uploads-playlist-id">Uploads Playlist ID</label></th>
                        <td><input id="rht-uploads-playlist-id" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[uploads_playlist_id]" value="<?php echo esc_attr($opts['uploads_playlist_id'] ?? ''); ?>" class="regular-text" />
                        <p class="description">Optional but recommended for lowest API usage. Usually your Channel ID with <code>UC</code> changed to <code>UU</code>. Example: <code>UUmyzLlMhXKK3J7MobxrpyJg</code>. This skips the <code>channels.list</code> lookup.</p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-cache-hours">Cache Hours</label></th>
                        <td><input id="rht-cache-hours" type="number" min="1" max="48" name="<?php echo esc_attr(self::OPTION_KEY); ?>[cache_hours]" value="<?php echo esc_attr($opts['cache_hours']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-max-videos">Video Pool Size</label></th>
                        <td><input id="rht-max-videos" type="number" min="5" max="50" name="<?php echo esc_attr(self::OPTION_KEY); ?>[max_videos]" value="<?php echo esc_attr($opts['max_videos']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-title">Section Title</label></th>
                        <td><input id="rht-title" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[title]" value="<?php echo esc_attr($opts['title']); ?>" class="regular-text" /></td>
                    </tr>

                    <tr>
                        <th scope="row"><label for="rht-short-title-marker">Short Title Marker</label></th>
                        <td><input id="rht-short-title-marker" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[short_title_marker]" value="<?php echo esc_attr($opts['short_title_marker']); ?>" class="regular-text" />
                        <p class="description">Add this marker to YouTube titles you want treated as Shorts, for example <code>Cybersecurity PSA [SHORT]</code>. Leave blank to fall back to duration-based detection when the API key is available.</p></td>
                    </tr>
                    <tr>
                        <th scope="row">Display Cleanup</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[hide_short_marker]" value="1" <?php checked(!empty($opts['hide_short_marker'])); ?> /> Hide the Short Title Marker when rendering titles on the site</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Video Filters</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[exclude_shorts]" value="1" <?php checked(!empty($opts['exclude_shorts'])); ?> /> Exclude videos marked as Shorts from the main showcase</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[exclude_premieres]" value="1" <?php checked(!empty($opts['exclude_premieres'])); ?> /> Exclude Premieres, upcoming, and live items</label>
                            <p class="description">If a Short Title Marker is configured, the plugin uses that marker instead of duration guessing. Duration-based filtering is only used as a fallback when no marker is configured and an API key is available.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function clear_cache() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('rht_yt_clear_cache');
        $this->delete_all_caches();
        wp_safe_redirect(admin_url('admin.php?page=ravenhawk-youtube-showcase&cache-cleared=1'));
        exit;
    }

    private function delete_all_caches() {
        delete_transient(self::CACHE_KEY);
        $opts = $this->options();
        $channel_id = sanitize_key($opts['channel_id'] ?? '');
        if (!empty($channel_id)) {
            delete_transient(self::CACHE_KEY . '_' . md5($channel_id));
        }
    }

    public function enqueue_assets() {
        $css = '
        .rht-yt-wrap{background:#050705;border:1px solid rgba(172,255,0,.28);box-shadow:0 0 28px rgba(0,255,65,.14);padding:28px;border-radius:18px;color:#fff;position:relative;overflow:hidden}.rht-yt-wrap:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 25% 0,rgba(0,255,55,.18),transparent 34%),linear-gradient(135deg,rgba(192,255,0,.08),transparent 45%);pointer-events:none}.rht-yt-title{position:relative;margin:0 0 20px;font-size:clamp(1.5rem,3vw,2.2rem);text-transform:uppercase;letter-spacing:.04em;color:#dfff00;text-shadow:0 0 14px rgba(0,255,60,.65)}.rht-yt-grid{position:relative;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}.rht-yt-card{background:rgba(0,0,0,.62);border:1px solid rgba(210,255,0,.33);border-radius:14px;overflow:hidden;box-shadow:0 0 18px rgba(0,255,55,.12)}.rht-yt-card.latest{border-color:#dfff00;box-shadow:0 0 22px rgba(210,255,0,.22)}.rht-yt-thumb{display:block;aspect-ratio:16/9;background:#111;position:relative}.rht-yt-thumb img{width:100%;height:100%;object-fit:cover;display:block}.rht-yt-badge{position:absolute;left:10px;top:10px;background:#dfff00;color:#050705;font-weight:800;font-size:.72rem;padding:5px 8px;border-radius:999px;text-transform:uppercase}.rht-yt-body{padding:14px}.rht-yt-card h3{font-size:1rem;line-height:1.3;margin:0 0 10px;color:#fff}.rht-yt-card a{color:inherit;text-decoration:none}.rht-yt-meta{font-size:.82rem;color:#b8ff9c}@media(max-width:850px){.rht-yt-grid{grid-template-columns:1fr}.rht-yt-wrap{padding:18px}}
        ';
        wp_register_style('rht-youtube-showcase', false, [], '1.2.4');
        wp_enqueue_style('rht-youtube-showcase');
        wp_add_inline_style('rht-youtube-showcase', $css);
    }

    public function render_shorts_shortcode($atts) {
        $atts = (array) $atts;
        $atts['type'] = 'shorts';
        if (empty($atts['title'])) {
            $atts['title'] = 'RavenHawk Tech Shorts';
        }
        return $this->render_shortcode($atts);
    }

    public function render_shortcode($atts) {
        $opts = $this->options();
        $atts = shortcode_atts(['title' => $opts['title'], 'channel_id' => '', 'type' => 'videos'], $atts, 'ravenhawk_youtube');
        $mode = strtolower(sanitize_key($atts['type']));
        if (!in_array($mode, ['videos', 'shorts'], true)) {
            $mode = 'videos';
        }
        if ($mode === 'shorts' && empty($atts['title'])) {
            $atts['title'] = 'RavenHawk Tech Shorts';
        }
        if (!empty($atts['channel_id'])) {
            $opts['channel_id'] = sanitize_text_field($atts['channel_id']);
        }

        $videos = $this->get_videos($opts, $mode);
        if (is_wp_error($videos)) {
            return '<div class="rht-yt-wrap"><p>' . esc_html($videos->get_error_message()) . '</p></div>';
        }
        if (count($videos) < 1) {
            return '<div class="rht-yt-wrap"><p>No videos found for this showcase.</p></div>';
        }

        $latest = $videos[0];
        $pool = array_slice($videos, 1);
        shuffle($pool);
        $selected = array_merge([$latest], array_slice($pool, 0, 2));

        ob_start();
        ?>
        <section class="rht-yt-wrap">
            <h2 class="rht-yt-title"><?php echo esc_html($atts['title']); ?></h2>
            <div class="rht-yt-grid">
                <?php foreach ($selected as $index => $video): ?>
                    <article class="rht-yt-card <?php echo $index === 0 ? 'latest' : ''; ?>">
                        <a class="rht-yt-thumb" href="<?php echo esc_url('https://www.youtube.com/watch?v=' . $video['id']); ?>" target="_blank" rel="noopener noreferrer">
                            <img src="<?php echo esc_url($video['thumbnail']); ?>" alt="<?php echo esc_attr($video['title']); ?>" loading="lazy">
                            <span class="rht-yt-badge"><?php echo $index === 0 ? 'Latest' : 'Random'; ?></span>
                        </a>
                        <div class="rht-yt-body">
                            <h3><a href="<?php echo esc_url('https://www.youtube.com/watch?v=' . $video['id']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($this->display_title($video['title'], $opts)); ?></a></h3>
                            <div class="rht-yt-meta"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($video['publishedAt']))); ?></div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private function get_videos($opts, $mode = 'videos') {
        $marker = trim((string) ($opts['short_title_marker'] ?? ''));
        $cache_key = self::CACHE_KEY . '_' . md5('v124|' . $mode . '|' . trim($opts['channel_id']) . '|' . trim($opts['channel_handle']) . '|' . trim($opts['uploads_playlist_id'] ?? '') . '|' . absint($opts['exclude_shorts'] ?? 1) . '|' . absint($opts['exclude_premieres'] ?? 1) . '|' . $marker);
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $channel_id = trim($opts['channel_id']);
        if (!empty($channel_id)) {
            $rss_videos = $this->get_videos_from_rss($channel_id, $opts);
            if (!is_wp_error($rss_videos) && !empty($rss_videos)) {
                if (!empty($opts['api_key']) && ((empty($marker) && ($mode === 'shorts' || !empty($opts['exclude_shorts']))) || !empty($opts['exclude_premieres']))) {
                    $filtered_rss_videos = $this->filter_videos_with_api($rss_videos, $opts, $mode);
                    if (!is_wp_error($filtered_rss_videos)) {
                        $rss_videos = $filtered_rss_videos;
                    }
                }
                $rss_videos = $this->filter_videos_by_mode($rss_videos, $opts, $mode);
                set_transient($cache_key, $rss_videos, HOUR_IN_SECONDS * $opts['cache_hours']);
                return $rss_videos;
            }
            // If RSS has an issue and there is no API key, show the RSS error.
            if (empty($opts['api_key'])) {
                return $rss_videos;
            }
        }

        if (empty($opts['api_key'])) {
            return new WP_Error('rht_missing_channel_or_api', 'Add your raw YouTube Channel ID for RSS, or add an API key plus Uploads Playlist ID for the lightweight API fallback.');
        }

        $uploads_playlist_id = trim($opts['uploads_playlist_id'] ?? '');

        // Lowest-quota API path: use the uploads playlist directly.
        // This avoids channels.list and uses only playlistItems.list.
        if (empty($uploads_playlist_id)) {
            if (empty($channel_id)) {
                $channel_id = $this->resolve_channel_id($opts);
                if (is_wp_error($channel_id)) {
                    return $channel_id;
                }
            }

            $uploads_playlist_id = $this->get_uploads_playlist_id($channel_id, $opts['api_key']);
            if (is_wp_error($uploads_playlist_id)) {
                return $uploads_playlist_id;
            }
        }

        $url = add_query_arg([
            'part' => 'snippet,contentDetails',
            'playlistId' => $uploads_playlist_id,
            'maxResults' => $opts['max_videos'],
            'key' => $opts['api_key'],
        ], 'https://www.googleapis.com/youtube/v3/playlistItems');

        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_http_error', 'YouTube request failed: ' . $response->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200) {
            return $this->youtube_api_error($body, 'Could not load YouTube videos from the uploads playlist.');
        }
        if (empty($body['items'])) {
            return new WP_Error('rht_youtube_no_videos', 'No uploaded YouTube videos were found for this channel.');
        }

        $videos = [];
        foreach ($body['items'] as $item) {
            $video_id = $item['contentDetails']['videoId'] ?? '';
            if (empty($video_id)) {
                continue;
            }
            $snippet = $item['snippet'] ?? [];
            if (!empty($snippet['title']) && in_array($snippet['title'], ['Deleted video', 'Private video'], true)) {
                continue;
            }
            $thumbs = $snippet['thumbnails'] ?? [];
            $thumb = $thumbs['maxres']['url'] ?? $thumbs['standard']['url'] ?? $thumbs['high']['url'] ?? $thumbs['medium']['url'] ?? $thumbs['default']['url'] ?? '';
            if (empty($thumb)) {
                $thumb = 'https://i.ytimg.com/vi/' . rawurlencode($video_id) . '/hqdefault.jpg';
            }
            $videos[] = [
                'id' => $video_id,
                'title' => html_entity_decode($snippet['title'] ?? '', ENT_QUOTES, 'UTF-8'),
                'thumbnail' => $thumb,
                'publishedAt' => $snippet['publishedAt'] ?? '',
            ];
        }

        if (!empty($opts['api_key']) && ((empty($marker) && ($mode === 'shorts' || !empty($opts['exclude_shorts']))) || !empty($opts['exclude_premieres']))) {
            $filtered_videos = $this->filter_videos_with_api($videos, $opts, $mode);
            if (!is_wp_error($filtered_videos)) {
                $videos = $filtered_videos;
            }
        }

        $videos = $this->filter_videos_by_mode($videos, $opts, $mode);

        if (empty($videos)) {
            return new WP_Error('rht_youtube_no_public_videos', 'No public uploaded videos were found for this channel after filters were applied.');
        }

        set_transient($cache_key, $videos, HOUR_IN_SECONDS * $opts['cache_hours']);
        return $videos;
    }

    private function get_videos_from_rss($channel_id, $opts) {
        $url = add_query_arg(['channel_id' => $channel_id], 'https://www.youtube.com/feeds/videos.xml');
        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_rss_http_error', 'YouTube RSS request failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw = wp_remote_retrieve_body($response);
        if ($code !== 200 || empty($raw)) {
            return new WP_Error('rht_youtube_rss_error', 'Could not load YouTube RSS feed. Check that the Channel ID is correct and public.');
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($raw);
        if (!$xml) {
            return new WP_Error('rht_youtube_rss_parse_error', 'Could not parse the YouTube RSS feed.');
        }

        $videos = [];
        $max = max(3, absint($opts['max_videos']));
        foreach ($xml->entry as $entry) {
            $media = $entry->children('media', true);
            $yt = $entry->children('yt', true);
            $video_id = (string) $yt->videoId;
            if (empty($video_id)) {
                $id_text = (string) $entry->id;
                $video_id = preg_replace('/^yt:video:/', '', $id_text);
            }
            if (empty($video_id)) {
                continue;
            }
            $thumb = '';
            if (isset($media->group->thumbnail)) {
                $attrs = $media->group->thumbnail->attributes();
                $thumb = isset($attrs['url']) ? (string) $attrs['url'] : '';
            }
            if (empty($thumb)) {
                $thumb = 'https://i.ytimg.com/vi/' . rawurlencode($video_id) . '/hqdefault.jpg';
            }
            $videos[] = [
                'id' => $video_id,
                'title' => html_entity_decode((string) $entry->title, ENT_QUOTES, 'UTF-8'),
                'thumbnail' => $thumb,
                'publishedAt' => (string) $entry->published,
            ];
            if (count($videos) >= $max) {
                break;
            }
        }

        if (empty($videos)) {
            return new WP_Error('rht_youtube_rss_no_videos', 'No public videos were found in the YouTube RSS feed for this Channel ID.');
        }
        return $videos;
    }


    private function filter_videos_by_mode($videos, $opts, $mode = 'videos') {
        $marker = trim((string) ($opts['short_title_marker'] ?? ''));
        if ($marker === '') {
            return $videos;
        }

        $filtered = [];
        foreach ($videos as $video) {
            $is_marked_short = $this->title_has_short_marker($video['title'] ?? '', $marker);
            if ($mode === 'shorts') {
                if ($is_marked_short) {
                    $filtered[] = $video;
                }
                continue;
            }

            if (!empty($opts['exclude_shorts']) && $is_marked_short) {
                continue;
            }
            $filtered[] = $video;
        }
        return $filtered;
    }

    private function title_has_short_marker($title, $marker) {
        $marker = trim((string) $marker);
        if ($marker === '') {
            return false;
        }
        return stripos((string) $title, $marker) !== false;
    }

    private function display_title($title, $opts) {
        $title = (string) $title;
        $marker = trim((string) ($opts['short_title_marker'] ?? ''));
        if (!empty($opts['hide_short_marker']) && $marker !== '') {
            $title = str_ireplace($marker, '', $title);
            $title = preg_replace('/\s{2,}/', ' ', $title);
            $title = trim($title);
        }
        return $title;
    }

    private function filter_videos_with_api($videos, $opts, $mode = 'videos') {
        if (empty($videos) || empty($opts['api_key'])) {
            return $videos;
        }

        $ids = [];
        foreach ($videos as $video) {
            if (!empty($video['id'])) {
                $ids[] = $video['id'];
            }
        }
        $ids = array_values(array_unique(array_filter($ids)));
        if (empty($ids)) {
            return $videos;
        }

        $allowed = [];
        foreach (array_chunk($ids, 50) as $chunk) {
            $url = add_query_arg([
                'part' => 'snippet,contentDetails,status',
                'id' => implode(',', $chunk),
                'key' => $opts['api_key'],
                'maxResults' => 50,
            ], 'https://www.googleapis.com/youtube/v3/videos');

            $response = wp_remote_get($url, ['timeout' => 15]);
            if (is_wp_error($response)) {
                return $response;
            }

            $code = wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($code !== 200) {
                return $this->youtube_api_error($body, 'Could not filter YouTube videos by duration and Premiere status.');
            }

            foreach (($body['items'] ?? []) as $item) {
                $id = $item['id'] ?? '';
                if (empty($id)) {
                    continue;
                }

                $snippet = $item['snippet'] ?? [];
                $status = $item['status'] ?? [];
                $content_details = $item['contentDetails'] ?? [];

                $duration_seconds = $this->youtube_duration_to_seconds($content_details['duration'] ?? '');
                $live_state = strtolower((string) ($snippet['liveBroadcastContent'] ?? 'none'));
                $privacy_status = strtolower((string) ($status['privacyStatus'] ?? ''));
                $upload_status = strtolower((string) ($status['uploadStatus'] ?? ''));

                if (empty($opts['short_title_marker'])) {
                    if ($mode === 'shorts' && !($duration_seconds > 0 && $duration_seconds <= 180)) {
                        continue;
                    }
                    if ($mode !== 'shorts' && !empty($opts['exclude_shorts']) && $duration_seconds > 0 && $duration_seconds <= 180) {
                        continue;
                    }
                }

                if (!empty($opts['exclude_premieres'])) {
                    if ($live_state !== '' && $live_state !== 'none') {
                        continue;
                    }
                    if ($privacy_status !== '' && $privacy_status !== 'public') {
                        continue;
                    }
                    if ($upload_status !== '' && $upload_status !== 'processed') {
                        continue;
                    }
                }

                $allowed[$id] = true;
            }
        }

        $filtered = [];
        foreach ($videos as $video) {
            if (!empty($video['id']) && isset($allowed[$video['id']])) {
                $filtered[] = $video;
            }
        }

        return $filtered;
    }

    private function youtube_duration_to_seconds($duration) {
        if (empty($duration) || !is_string($duration)) {
            return 0;
        }

        try {
            $interval = new DateInterval($duration);
        } catch (Exception $e) {
            return 0;
        }

        return ($interval->y * YEAR_IN_SECONDS)
            + ($interval->m * MONTH_IN_SECONDS)
            + ($interval->d * DAY_IN_SECONDS)
            + ($interval->h * HOUR_IN_SECONDS)
            + ($interval->i * MINUTE_IN_SECONDS)
            + $interval->s;
    }

    private function get_uploads_playlist_id($channel_id, $api_key) {
        // Fallback only. Supplying Uploads Playlist ID in settings skips this API request.
        $url = add_query_arg([
            'part' => 'contentDetails',
            'id' => $channel_id,
            'key' => $api_key,
        ], 'https://www.googleapis.com/youtube/v3/channels');

        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_http_error', 'YouTube channel request failed: ' . $response->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200) {
            return $this->youtube_api_error($body, 'Could not load the YouTube channel uploads playlist.');
        }

        $playlist_id = $body['items'][0]['contentDetails']['relatedPlaylists']['uploads'] ?? '';
        if (empty($playlist_id)) {
            return new WP_Error('rht_uploads_playlist_missing', 'Could not find the uploads playlist for this Channel ID. Check that the Channel ID is correct.');
        }
        return $playlist_id;
    }

    private function youtube_api_error($body, $fallback) {
        $message = $body['error']['message'] ?? '';
        $reason = $body['error']['errors'][0]['reason'] ?? '';
        $details = trim($message . ($reason ? ' Reason: ' . $reason : ''));
        if ($details) {
            return new WP_Error('rht_youtube_api_error', $fallback . ' YouTube API said: ' . $details);
        }
        return new WP_Error('rht_youtube_api_error', $fallback . ' Check your API key, enabled APIs, quota, referrer restrictions, and Channel ID.');
    }

    private function resolve_channel_id($opts) {
        $handle = ltrim(trim($opts['channel_handle']), '@');
        if (empty($handle)) {
            return new WP_Error('rht_missing_channel', 'Add a YouTube channel handle or channel ID in settings.');
        }
        $url = add_query_arg([
            'part' => 'id',
            'forHandle' => '@' . $handle,
            'key' => $opts['api_key'],
        ], 'https://www.googleapis.com/youtube/v3/channels');
        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return $response;
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['items'][0]['id'])) {
            return new WP_Error('rht_channel_not_found', 'Could not resolve the YouTube channel handle. Try entering the Channel ID directly.');
        }
        return $body['items'][0]['id'];
    }
}

new RavenHawk_YouTube_Showcase();
