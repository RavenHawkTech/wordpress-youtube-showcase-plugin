# RavenHawk YouTube Showcase

WordPress shortcode plugin for displaying RavenHawk Tech YouTube content.

## Shortcodes

- `[ravenhawk_youtube]` - main long-form showcase
- `[ravenhawk_youtube_showcase]` - alias for the main showcase
- `[ravenhawk_youtube_shorts]` - Shorts-only showcase
- `[ravenhawk_youtube type="shorts"]` - Shorts mode through the main shortcode

## Shorts filtering

Version 1.2.5 adds a creator-controlled Short Title Marker.

Default marker:

```text
[SHORT]
```

Example YouTube title:

```text
Scams and Phishing PSA [SHORT]
```

When the marker is configured:

- the main showcase excludes marked Shorts
- the Shorts shortcode includes only marked Shorts
- the marker can be hidden from displayed site titles
- no API duration guessing is needed for Shorts classification

If the marker is blank, the plugin can fall back to duration-based detection when a YouTube Data API key is configured.

## Premiere filtering

Excluding Premieres, upcoming videos, and live items still requires the YouTube Data API key.


## v1.2.5
- Restores the settings page under the RavenHawkTech admin menu instead of WordPress Settings.
- Updates cache-clear redirect to the RavenHawkTech admin menu page.
