# RavenHawk YouTube Showcase 2.1.0

This version keeps the preferred v1.2.x visual layout while reducing YouTube API usage.

## API reduction changes

- RSS is still attempted first when a Channel ID is configured.
- Added an Uploads Playlist ID setting.
- If Uploads Playlist ID is configured, the plugin skips `channels.list`.
- API fallback uses only `playlistItems.list`.
- Default cache increased to 12 hours.
- Added thumbnail fallback to prevent broken cards.

## Recommended RavenHawkTech settings

Channel ID:

```text
UCmyzLlMhXKK3J7MobxrpyJg
```

Uploads Playlist ID:

```text
UUmyzLlMhXKK3J7MobxrpyJg
```

Shortcode:

```text
[ravenhawk_youtube]
```


## Editable colors

Version 2.1.0 adds tabbed admin controls under **RavenHawkTech → YouTube Showcase**. Site admins can adjust the showcase background, accent, glow, card, text, meta text, badge text, and border radius settings without editing plugin code.


## Tabbed admin settings

Version 2.1.0 separates the admin screen into **General Settings** and **Style / Colors** tabs so YouTube connection settings and color controls are easier to manage.
