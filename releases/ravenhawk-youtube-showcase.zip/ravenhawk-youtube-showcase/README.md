# RavenHawk YouTube Showcase v1.2.3

Displays the latest RavenHawkTech YouTube video plus two random videos using `[ravenhawk_youtube]`.

## Changes in v1.2.3

- Added settings to exclude Shorts and Premiere/upcoming/live videos.
- Shorts filtering uses the YouTube Data API `videos.list` metadata pass and excludes videos 180 seconds or less.
- Premiere filtering excludes upcoming/live items and non-public/non-processed items.
- Cache key was bumped so existing cached results do not keep showing old filtered videos.

## Important filtering note

YouTube RSS does not include enough metadata to reliably detect Shorts duration or Premiere/upcoming state. For filtering to work, save a YouTube Data API key in the plugin settings. The plugin still uses RSS first for low quota usage, then performs a lightweight `videos.list` metadata lookup to filter the results.

## Recommended RavenHawkTech settings

Channel ID:

```text
UCmyzLlMhXKK3J7MobxrpyJg
```

Uploads Playlist ID:

```text
UUmyzLlMhXKK3J7MobxrpyJg
```

Shortcode:

```text
[ravenhawk_youtube]
```
