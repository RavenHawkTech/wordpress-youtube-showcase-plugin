<?php
/**
 * Plugin Name: RavenHawk YouTube Showcase
 * Plugin URI: https://ravenhawktech.com
 * Description: Displays a styled YouTube video showcase with shortcode support, RSS-first loading, API fallback, and editable colors. Visit https://ravenhawktech.com for RavenHawkTech.
 * Version: 2.1.0
 * Author: RavenHawkTech
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

class RavenHawk_YouTube_Showcase {
    const OPTION_KEY = 'rht_yt_showcase_options';
    const CACHE_KEY  = 'rht_yt_showcase_videos';
    const VERSION    = '2.1.0';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('ravenhawk_youtube', [$this, 'render_shortcode']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_post_rht_yt_clear_cache', [$this, 'clear_cache']);
    }

    public static function defaults() {
        return [
            'api_key' => '',
            'channel_handle' => '@RavenHawkTech',
            'channel_id' => '',
            'uploads_playlist_id' => '',
            'cache_hours' => 12,
            'max_videos' => 25,
            'title' => 'Latest from RavenHawk Tech',
            'background_color' => '#050705',
            'accent_color' => '#dfff00',
            'accent_glow_color' => '#00ff41',
            'card_background_color' => '#000000',
            'card_border_color' => '#d2ff00',
            'text_color' => '#ffffff',
            'meta_text_color' => '#b8ff9c',
            'badge_text_color' => '#050705',
            'outer_radius' => 18,
            'card_radius' => 14,
        ];
    }

    public function options() {
        return wp_parse_args(get_option(self::OPTION_KEY, []), self::defaults());
    }

    public function add_settings_page() {
        if (!$this->admin_menu_slug_exists('ravenhawktech')) {
            add_menu_page(
                'RavenHawkTech',
                'RavenHawkTech',
                'manage_options',
                'ravenhawktech',
                [$this, 'ravenhawktech_page'],
                $this->admin_menu_icon_url(),
                81
            );
        }

        add_submenu_page(
            'ravenhawktech',
            'RavenHawk YouTube Showcase',
            'YouTube Showcase',
            'manage_options',
            'ravenhawk-youtube-showcase',
            [$this, 'settings_page']
        );
    }

    private function admin_menu_slug_exists($slug) {
        global $menu;

        if (!is_array($menu)) {
            return false;
        }

        foreach ($menu as $item) {
            if (isset($item[2]) && $item[2] === $slug) {
                return true;
            }
        }

        return false;
    }

    private function admin_menu_icon_url() {
        $icon_path = plugin_dir_path(__FILE__) . 'assets/rht-admin-menu-icon.png';
        if (file_exists($icon_path)) {
            return plugin_dir_url(__FILE__) . 'assets/rht-admin-menu-icon.png';
        }

        return 'dashicons-video-alt3';
    }

    private function branding_icon_url() {
        $icon_path = plugin_dir_path(__FILE__) . 'assets/rht-admin-heading-icon.png';
        if (file_exists($icon_path)) {
            return plugin_dir_url(__FILE__) . 'assets/rht-admin-heading-icon.png';
        }

        return '';
    }

    public function ravenhawktech_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $icon_url = $this->branding_icon_url();
        ?>
        <div class="wrap">
            <h1>
                <?php if ($icon_url): ?>
                    <img src="<?php echo esc_url($icon_url); ?>" alt="" style="width: 20px; height: 20px; vertical-align: text-bottom; margin-right: 6px;">
                <?php endif; ?>
                <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>
            </h1>
            <p>RavenHawkTech WordPress tools and connectors.</p>
            <p><a class="button button-primary" href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">Visit RavenHawkTech</a></p>
        </div>
        <?php
    }

    public function register_settings() {
        register_setting('rht_yt_showcase_group', self::OPTION_KEY, [$this, 'sanitize_options']);
    }

    public function sanitize_options($input) {
        $defaults = self::defaults();
        $out = [];
        $out['api_key'] = sanitize_text_field($input['api_key'] ?? '');
        $out['channel_handle'] = sanitize_text_field($input['channel_handle'] ?? $defaults['channel_handle']);
        $out['channel_id'] = sanitize_text_field($input['channel_id'] ?? '');
        $out['uploads_playlist_id'] = sanitize_text_field($input['uploads_playlist_id'] ?? '');
        $out['cache_hours'] = max(1, absint($input['cache_hours'] ?? $defaults['cache_hours']));
        $out['max_videos'] = min(50, max(5, absint($input['max_videos'] ?? $defaults['max_videos'])));
        $out['title'] = sanitize_text_field($input['title'] ?? $defaults['title']);

        foreach ([
            'background_color',
            'accent_color',
            'accent_glow_color',
            'card_background_color',
            'card_border_color',
            'text_color',
            'meta_text_color',
            'badge_text_color',
        ] as $color_key) {
            $color = sanitize_hex_color($input[$color_key] ?? $defaults[$color_key]);
            $out[$color_key] = $color ?: $defaults[$color_key];
        }

        $out['outer_radius'] = min(60, max(0, absint($input['outer_radius'] ?? $defaults['outer_radius'])));
        $out['card_radius'] = min(60, max(0, absint($input['card_radius'] ?? $defaults['card_radius'])));

        $this->delete_all_caches();
        return $out;
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $opts = $this->options();
        $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'general';
        if (!in_array($active_tab, ['general', 'style'], true)) {
            $active_tab = 'general';
        }
        ?>
        <div class="wrap">
            <h1>RavenHawk YouTube Showcase</h1>
            <p>Use shortcode: <code>[ravenhawk_youtube]</code></p>

            <h2 class="nav-tab-wrapper">
                <a href="<?php echo esc_url(admin_url('admin.php?page=ravenhawk-youtube-showcase&tab=general')); ?>" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">General Settings</a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=ravenhawk-youtube-showcase&tab=style')); ?>" class="nav-tab <?php echo $active_tab === 'style' ? 'nav-tab-active' : ''; ?>">Style / Colors</a>
            </h2>

            <form method="post" action="options.php">
                <?php settings_fields('rht_yt_showcase_group'); ?>

                <?php if ($active_tab === 'general'): ?>
                    <p><strong>Important:</strong> Use your raw Channel ID and, when possible, the Uploads Playlist ID. The Uploads Playlist ID reduces API requests by skipping channel lookup.</p>

                    <?php if (!empty($opts['channel_id'])): ?>
                        <p>Current RSS feed: <code><?php echo esc_html('https://www.youtube.com/feeds/videos.xml?channel_id=' . $opts['channel_id']); ?></code></p>
                    <?php endif; ?>

                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="rht-api-key">YouTube Data API Key</label></th>
                            <td>
                                <input id="rht-api-key" type="password" name="<?php echo esc_attr(self::OPTION_KEY); ?>[api_key]" value="<?php echo esc_attr($opts['api_key']); ?>" class="regular-text" autocomplete="off" />
                                <p class="description">Optional. The plugin uses YouTube RSS first, which does not consume YouTube API quota. Keep the key only as a fallback.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-channel-handle">Channel Handle</label></th>
                            <td><input id="rht-channel-handle" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[channel_handle]" value="<?php echo esc_attr($opts['channel_handle']); ?>" class="regular-text" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-channel-id">Channel ID optional</label></th>
                            <td>
                                <input id="rht-channel-id" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[channel_id]" value="<?php echo esc_attr($opts['channel_id']); ?>" class="regular-text" />
                                <p class="description">Recommended: paste the raw Channel ID, for example <code>UCxxxxxxxxxxxxxxxxxxxxxx</code>. The plugin uses RSS first, then direct uploads playlist API fallback to reduce quota usage.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-uploads-playlist-id">Uploads Playlist ID</label></th>
                            <td>
                                <input id="rht-uploads-playlist-id" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[uploads_playlist_id]" value="<?php echo esc_attr($opts['uploads_playlist_id'] ?? ''); ?>" class="regular-text" />
                                <p class="description">Optional but recommended for lowest API usage. Usually your Channel ID with <code>UC</code> changed to <code>UU</code>. Example: <code>UUmyzLlMhXKK3J7MobxrpyJg</code>. This skips the <code>channels.list</code> lookup.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-cache-hours">Cache Hours</label></th>
                            <td><input id="rht-cache-hours" type="number" min="1" max="48" name="<?php echo esc_attr(self::OPTION_KEY); ?>[cache_hours]" value="<?php echo esc_attr($opts['cache_hours']); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-max-videos">Video Pool Size</label></th>
                            <td><input id="rht-max-videos" type="number" min="5" max="50" name="<?php echo esc_attr(self::OPTION_KEY); ?>[max_videos]" value="<?php echo esc_attr($opts['max_videos']); ?>" /></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-title">Section Title</label></th>
                            <td><input id="rht-title" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[title]" value="<?php echo esc_attr($opts['title']); ?>" class="regular-text" /></td>
                        </tr>
                    </table>

                    <?php submit_button('Save General Settings'); ?>
                <?php else: ?>
                    <p>Customize the YouTube showcase colors without editing plugin CSS.</p>

                    <table class="form-table" role="presentation">
                        <?php
                        $color_fields = [
                            'background_color' => 'Background color',
                            'accent_color' => 'Accent color',
                            'accent_glow_color' => 'Glow color',
                            'card_background_color' => 'Card background color',
                            'card_border_color' => 'Card border color',
                            'text_color' => 'Main text color',
                            'meta_text_color' => 'Meta/date text color',
                            'badge_text_color' => 'Badge text color',
                        ];

                        foreach ($color_fields as $key => $label): ?>
                            <tr>
                                <th scope="row"><label for="rht-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th>
                                <td>
                                    <input id="rht-<?php echo esc_attr($key); ?>" type="color" name="<?php echo esc_attr(self::OPTION_KEY); ?>[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($opts[$key]); ?>" />
                                    <code><?php echo esc_html($opts[$key]); ?></code>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <tr>
                            <th scope="row"><label for="rht-outer-radius">Outer border radius</label></th>
                            <td><input id="rht-outer-radius" type="number" min="0" max="60" name="<?php echo esc_attr(self::OPTION_KEY); ?>[outer_radius]" value="<?php echo esc_attr($opts['outer_radius']); ?>" /> px</td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="rht-card-radius">Card border radius</label></th>
                            <td><input id="rht-card-radius" type="number" min="0" max="60" name="<?php echo esc_attr(self::OPTION_KEY); ?>[card_radius]" value="<?php echo esc_attr($opts['card_radius']); ?>" /> px</td>
                        </tr>
                    </table>

                    <?php submit_button('Save Style / Colors'); ?>
                <?php endif; ?>
            </form>

            <?php if ($active_tab === 'general' && !empty($opts['channel_id'])): ?>
                <hr>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin: 12px 0 20px;">
                    <?php wp_nonce_field('rht_yt_clear_cache'); ?>
                    <input type="hidden" name="action" value="rht_yt_clear_cache" />
                    <?php submit_button('Clear YouTube Video Cache', 'secondary', 'submit', false); ?>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    public function clear_cache() {
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('rht_yt_clear_cache');
        $this->delete_all_caches();
        wp_safe_redirect(admin_url('options-general.php?page=ravenhawk-youtube-showcase&cache-cleared=1'));
        exit;
    }

    private function delete_all_caches() {
        delete_transient(self::CACHE_KEY);
        $opts = $this->options();
        $channel_id = sanitize_key($opts['channel_id'] ?? '');
        if (!empty($channel_id)) {
            delete_transient(self::CACHE_KEY . '_' . md5($channel_id));
        }
    }

    public function enqueue_assets() {
        $opts = $this->options();
        $accent_rgb = $this->hex_to_rgb_string($opts['accent_color']);
        $glow_rgb = $this->hex_to_rgb_string($opts['accent_glow_color']);
        $card_border_rgb = $this->hex_to_rgb_string($opts['card_border_color']);

        $css = '
        .rht-yt-wrap{
            --rht-yt-bg:' . esc_html($opts['background_color']) . ';
            --rht-yt-accent:' . esc_html($opts['accent_color']) . ';
            --rht-yt-accent-rgb:' . esc_html($accent_rgb) . ';
            --rht-yt-glow:' . esc_html($opts['accent_glow_color']) . ';
            --rht-yt-glow-rgb:' . esc_html($glow_rgb) . ';
            --rht-yt-card-bg:' . esc_html($opts['card_background_color']) . ';
            --rht-yt-card-border:' . esc_html($opts['card_border_color']) . ';
            --rht-yt-card-border-rgb:' . esc_html($card_border_rgb) . ';
            --rht-yt-text:' . esc_html($opts['text_color']) . ';
            --rht-yt-meta:' . esc_html($opts['meta_text_color']) . ';
            --rht-yt-badge-text:' . esc_html($opts['badge_text_color']) . ';
            --rht-yt-radius:' . absint($opts['outer_radius']) . 'px;
            --rht-yt-card-radius:' . absint($opts['card_radius']) . 'px;
            background:var(--rht-yt-bg,#050705);
            border:1px solid rgba(var(--rht-yt-card-border-rgb,210,255,0),.28);
            box-shadow:0 0 28px rgba(var(--rht-yt-glow-rgb,0,255,65),.14);
            padding:28px;
            border-radius:var(--rht-yt-radius,18px);
            color:var(--rht-yt-text,#fff);
            position:relative;
            overflow:hidden
        }
        .rht-yt-wrap:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 25% 0,rgba(var(--rht-yt-glow-rgb,0,255,55),.18),transparent 34%),linear-gradient(135deg,rgba(var(--rht-yt-accent-rgb,223,255,0),.08),transparent 45%);pointer-events:none}
        .rht-yt-title{position:relative;margin:0 0 20px;font-size:clamp(1.5rem,3vw,2.2rem);text-transform:uppercase;letter-spacing:.04em;color:var(--rht-yt-accent,#dfff00);text-shadow:0 0 14px rgba(var(--rht-yt-glow-rgb,0,255,60),.65)}
        .rht-yt-grid{position:relative;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px}
        .rht-yt-card{background:color-mix(in srgb,var(--rht-yt-card-bg,#000) 62%,transparent);border:1px solid rgba(var(--rht-yt-card-border-rgb,210,255,0),.33);border-radius:var(--rht-yt-card-radius,14px);overflow:hidden;box-shadow:0 0 18px rgba(var(--rht-yt-glow-rgb,0,255,55),.12)}
        .rht-yt-card.latest{border-color:var(--rht-yt-accent,#dfff00);box-shadow:0 0 22px rgba(var(--rht-yt-accent-rgb,210,255,0),.22)}
        .rht-yt-thumb{display:block;aspect-ratio:16/9;background:#111;position:relative}
        .rht-yt-thumb img{width:100%;height:100%;object-fit:cover;display:block}
        .rht-yt-badge{position:absolute;left:10px;top:10px;background:var(--rht-yt-accent,#dfff00);color:var(--rht-yt-badge-text,#050705);font-weight:800;font-size:.72rem;padding:5px 8px;border-radius:999px;text-transform:uppercase}
        .rht-yt-body{padding:14px}
        .rht-yt-card h3{font-size:1rem;line-height:1.3;margin:0 0 10px;color:var(--rht-yt-text,#fff)}
        .rht-yt-card a{color:inherit;text-decoration:none}
        .rht-yt-meta{font-size:.82rem;color:var(--rht-yt-meta,#b8ff9c)}
        @media(max-width:850px){.rht-yt-grid{grid-template-columns:1fr}.rht-yt-wrap{padding:18px}}
        ';
        wp_register_style('rht-youtube-showcase', false, [], self::VERSION);
        wp_enqueue_style('rht-youtube-showcase');
        wp_add_inline_style('rht-youtube-showcase', $css);
    }

    private function hex_to_rgb_string($hex) {
        $hex = ltrim((string) $hex, '#');

        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        if (strlen($hex) !== 6) {
            return '223,255,0';
        }

        return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
    }

    public function render_shortcode($atts) {
        $opts = $this->options();
        $atts = shortcode_atts(['title' => $opts['title'], 'channel_id' => ''], $atts, 'ravenhawk_youtube');
        if (!empty($atts['channel_id'])) {
            $opts['channel_id'] = sanitize_text_field($atts['channel_id']);
        }

        $videos = $this->get_videos($opts);
        if (is_wp_error($videos)) {
            return '<div class="rht-yt-wrap"><p>' . esc_html($videos->get_error_message()) . '</p></div>';
        }
        if (count($videos) < 1) {
            return '<div class="rht-yt-wrap"><p>No videos found.</p></div>';
        }

        $latest = $videos[0];
        $pool = array_slice($videos, 1);
        shuffle($pool);
        $selected = array_merge([$latest], array_slice($pool, 0, 2));

        ob_start();
        ?>
        <section class="rht-yt-wrap">
            <h2 class="rht-yt-title"><?php echo esc_html($atts['title']); ?></h2>
            <div class="rht-yt-grid">
                <?php foreach ($selected as $index => $video): ?>
                    <article class="rht-yt-card <?php echo $index === 0 ? 'latest' : ''; ?>">
                        <a class="rht-yt-thumb" href="<?php echo esc_url('https://www.youtube.com/watch?v=' . $video['id']); ?>" target="_blank" rel="noopener noreferrer">
                            <img src="<?php echo esc_url($video['thumbnail']); ?>" alt="<?php echo esc_attr($video['title']); ?>" loading="lazy">
                            <span class="rht-yt-badge"><?php echo $index === 0 ? 'Latest' : 'Random'; ?></span>
                        </a>
                        <div class="rht-yt-body">
                            <h3><a href="<?php echo esc_url('https://www.youtube.com/watch?v=' . $video['id']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($video['title']); ?></a></h3>
                            <div class="rht-yt-meta"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($video['publishedAt']))); ?></div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
        <?php
        return ob_get_clean();
    }

    private function get_videos($opts) {
        $cache_key = self::CACHE_KEY . '_' . md5(trim($opts['channel_id']) . '|' . trim($opts['channel_handle']) . '|' . trim($opts['uploads_playlist_id'] ?? ''));
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $channel_id = trim($opts['channel_id']);
        if (!empty($channel_id)) {
            $rss_videos = $this->get_videos_from_rss($channel_id, $opts);
            if (!is_wp_error($rss_videos) && !empty($rss_videos)) {
                set_transient($cache_key, $rss_videos, HOUR_IN_SECONDS * $opts['cache_hours']);
                return $rss_videos;
            }
            // If RSS has an issue and there is no API key, show the RSS error.
            if (empty($opts['api_key'])) {
                return $rss_videos;
            }
        }

        if (empty($opts['api_key'])) {
            return new WP_Error('rht_missing_channel_or_api', 'Add your raw YouTube Channel ID for RSS, or add an API key plus Uploads Playlist ID for the lightweight API fallback.');
        }

        $uploads_playlist_id = trim($opts['uploads_playlist_id'] ?? '');

        // Lowest-quota API path: use the uploads playlist directly.
        // This avoids channels.list and uses only playlistItems.list.
        if (empty($uploads_playlist_id)) {
            if (empty($channel_id)) {
                $channel_id = $this->resolve_channel_id($opts);
                if (is_wp_error($channel_id)) {
                    return $channel_id;
                }
            }

            $uploads_playlist_id = $this->get_uploads_playlist_id($channel_id, $opts['api_key']);
            if (is_wp_error($uploads_playlist_id)) {
                return $uploads_playlist_id;
            }
        }

        $url = add_query_arg([
            'part' => 'snippet,contentDetails',
            'playlistId' => $uploads_playlist_id,
            'maxResults' => $opts['max_videos'],
            'key' => $opts['api_key'],
        ], 'https://www.googleapis.com/youtube/v3/playlistItems');

        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_http_error', 'YouTube request failed: ' . $response->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200) {
            return $this->youtube_api_error($body, 'Could not load YouTube videos from the uploads playlist.');
        }
        if (empty($body['items'])) {
            return new WP_Error('rht_youtube_no_videos', 'No uploaded YouTube videos were found for this channel.');
        }

        $videos = [];
        foreach ($body['items'] as $item) {
            $video_id = $item['contentDetails']['videoId'] ?? '';
            if (empty($video_id)) {
                continue;
            }
            $snippet = $item['snippet'] ?? [];
            if (!empty($snippet['title']) && in_array($snippet['title'], ['Deleted video', 'Private video'], true)) {
                continue;
            }
            $thumbs = $snippet['thumbnails'] ?? [];
            $thumb = $thumbs['maxres']['url'] ?? $thumbs['standard']['url'] ?? $thumbs['high']['url'] ?? $thumbs['medium']['url'] ?? $thumbs['default']['url'] ?? '';
            if (empty($thumb)) {
                $thumb = 'https://i.ytimg.com/vi/' . rawurlencode($video_id) . '/hqdefault.jpg';
            }
            $videos[] = [
                'id' => $video_id,
                'title' => html_entity_decode($snippet['title'] ?? '', ENT_QUOTES, 'UTF-8'),
                'thumbnail' => $thumb,
                'publishedAt' => $snippet['publishedAt'] ?? '',
            ];
        }

        if (empty($videos)) {
            return new WP_Error('rht_youtube_no_public_videos', 'No public uploaded YouTube videos were found for this channel.');
        }

        set_transient($cache_key, $videos, HOUR_IN_SECONDS * $opts['cache_hours']);
        return $videos;
    }

    private function get_videos_from_rss($channel_id, $opts) {
        $url = add_query_arg(['channel_id' => $channel_id], 'https://www.youtube.com/feeds/videos.xml');
        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_rss_http_error', 'YouTube RSS request failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw = wp_remote_retrieve_body($response);
        if ($code !== 200 || empty($raw)) {
            return new WP_Error('rht_youtube_rss_error', 'Could not load YouTube RSS feed. Check that the Channel ID is correct and public.');
        }

        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($raw);
        if (!$xml) {
            return new WP_Error('rht_youtube_rss_parse_error', 'Could not parse the YouTube RSS feed.');
        }

        $videos = [];
        $max = max(3, absint($opts['max_videos']));
        foreach ($xml->entry as $entry) {
            $media = $entry->children('media', true);
            $yt = $entry->children('yt', true);
            $video_id = (string) $yt->videoId;
            if (empty($video_id)) {
                $id_text = (string) $entry->id;
                $video_id = preg_replace('/^yt:video:/', '', $id_text);
            }
            if (empty($video_id)) {
                continue;
            }
            $thumb = '';
            if (isset($media->group->thumbnail)) {
                $attrs = $media->group->thumbnail->attributes();
                $thumb = isset($attrs['url']) ? (string) $attrs['url'] : '';
            }
            if (empty($thumb)) {
                $thumb = 'https://i.ytimg.com/vi/' . rawurlencode($video_id) . '/hqdefault.jpg';
            }
            $videos[] = [
                'id' => $video_id,
                'title' => html_entity_decode((string) $entry->title, ENT_QUOTES, 'UTF-8'),
                'thumbnail' => $thumb,
                'publishedAt' => (string) $entry->published,
            ];
            if (count($videos) >= $max) {
                break;
            }
        }

        if (empty($videos)) {
            return new WP_Error('rht_youtube_rss_no_videos', 'No public videos were found in the YouTube RSS feed for this Channel ID.');
        }
        return $videos;
    }

    private function get_uploads_playlist_id($channel_id, $api_key) {
        // Fallback only. Supplying Uploads Playlist ID in settings skips this API request.
        $url = add_query_arg([
            'part' => 'contentDetails',
            'id' => $channel_id,
            'key' => $api_key,
        ], 'https://www.googleapis.com/youtube/v3/channels');

        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return new WP_Error('rht_youtube_http_error', 'YouTube channel request failed: ' . $response->get_error_message());
        }
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code !== 200) {
            return $this->youtube_api_error($body, 'Could not load the YouTube channel uploads playlist.');
        }

        $playlist_id = $body['items'][0]['contentDetails']['relatedPlaylists']['uploads'] ?? '';
        if (empty($playlist_id)) {
            return new WP_Error('rht_uploads_playlist_missing', 'Could not find the uploads playlist for this Channel ID. Check that the Channel ID is correct.');
        }
        return $playlist_id;
    }

    private function youtube_api_error($body, $fallback) {
        $message = $body['error']['message'] ?? '';
        $reason = $body['error']['errors'][0]['reason'] ?? '';
        $details = trim($message . ($reason ? ' Reason: ' . $reason : ''));
        if ($details) {
            return new WP_Error('rht_youtube_api_error', $fallback . ' YouTube API said: ' . $details);
        }
        return new WP_Error('rht_youtube_api_error', $fallback . ' Check your API key, enabled APIs, quota, referrer restrictions, and Channel ID.');
    }

    private function resolve_channel_id($opts) {
        $handle = ltrim(trim($opts['channel_handle']), '@');
        if (empty($handle)) {
            return new WP_Error('rht_missing_channel', 'Add a YouTube channel handle or channel ID in settings.');
        }
        $url = add_query_arg([
            'part' => 'id',
            'forHandle' => '@' . $handle,
            'key' => $opts['api_key'],
        ], 'https://www.googleapis.com/youtube/v3/channels');
        $response = wp_remote_get($url, ['timeout' => 15]);
        if (is_wp_error($response)) {
            return $response;
        }
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['items'][0]['id'])) {
            return new WP_Error('rht_channel_not_found', 'Could not resolve the YouTube channel handle. Try entering the Channel ID directly.');
        }
        return $body['items'][0]['id'];
    }
}

new RavenHawk_YouTube_Showcase();
